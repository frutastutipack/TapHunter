
package com.example.taphunter;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int score = 0;
    TextView scoreText, timerText;
    View target;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scoreText = findViewById(R.id.scoreText);
        timerText = findViewById(R.id.timerText);
        target = findViewById(R.id.target);

        target.setOnClickListener(v -> {
            score++;
            scoreText.setText("Puntos: " + score);
            move();
        });

        new CountDownTimer(30000,1000){
            public void onTick(long m){ timerText.setText("Tiempo: "+m/1000); }
            public void onFinish(){ timerText.setText("Fin"); target.setEnabled(false); }
        }.start();
    }

    void move(){
        View p=(View)target.getParent();
        if(p.getWidth()>0)
            target.setX(random.nextInt(p.getWidth()-target.getWidth()));
        if(p.getHeight()>0)
            target.setY(random.nextInt(p.getHeight()-target.getHeight()));
    }
}
